class ParkingStall
{
private:
    int stallId;
    string locationIdentifier;
    vector<int> vehicles; // vehicle id
};
