class Fine
{
private:
    double amount;
    string reason;

public:
    double calculateFine();
};