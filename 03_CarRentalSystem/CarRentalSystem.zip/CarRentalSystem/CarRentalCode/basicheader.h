#ifndef BASIC_HEADER_H
#define BASIC_HEADER_H
#include <string>
#include <vector>
#include <iostream>

using namespace std;
#endif