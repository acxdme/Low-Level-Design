package models;

import java.util.List;

public class ElevatorPanel {
    private List<ElevatorButton> floorBtns;
    private ElevatorButton openDoorBtn;
    private ElevatorButton closeDoorBtn;
}
