package models;

import constants.DirectionStatus;

public class Display {

    private int floorNumber;
    private int capacity;
    private DirectionStatus direction;
}
