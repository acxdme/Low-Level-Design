package models;

import constants.DoorStatus;

public class Door {
    private DoorStatus status;
}
