package models;

import java.util.List;

public class Floor {

    private int id;
    private List<HallPanel> floorPanel;
    private List<Display> floorDisplay;
}
