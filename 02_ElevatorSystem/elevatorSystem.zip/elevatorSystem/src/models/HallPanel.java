package models;

public class HallPanel {
    private HallButton upButton;
    private HallButton downButton;
}
