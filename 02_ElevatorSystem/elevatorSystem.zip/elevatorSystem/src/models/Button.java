package models;

public abstract class Button {
    private boolean status;
    //TODO: Please add your getters/setters
    public abstract void press();
    public abstract boolean isPressed();
}
