package models;

import constants.DoorStatus;
import constants.ElevatorStatus;

public class Elevator {
    private int id;
    private Door elevatorDoor;
    private Display elevatorDisplay;
    private ElevatorStatus elevatorState;
    private ElevatorPanel elevatorPanel;
    //TODO: mark the below property as constant - 650KG
    private int maxCapacity;


    private void move() {

    }
    private void stop() {

    }
    private void openDoor() {

    }
    private void closeDoor() {

    }


}
