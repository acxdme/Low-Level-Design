package constants;

public enum ElevatorStatus {
    MOVE_UP, MOVE_DOWN, IDLE
}
