package constants;

public enum DoorStatus {
    OPEN, CLOSE
}
