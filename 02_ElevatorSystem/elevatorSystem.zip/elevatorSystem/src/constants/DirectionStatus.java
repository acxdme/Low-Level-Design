package constants;

public enum DirectionStatus {
    UP, DOWN
}
